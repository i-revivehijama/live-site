"use client";
import { useEffect, useState } from "react";
import { FaArrowLeft, FaArrowRight, FaStar } from "react-icons/fa";
import { motion } from "framer-motion";
import AOS from "aos";
import { testimonials } from "../../data/testimonialsData";
import "aos/dist/aos.css";

export default function Testimonial() {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    AOS.init({ duration: 1000 });
  }, []);

  const nextTestimonial = () => {
    setIndex((prev) => (prev + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  return (
    <section
      className="bg-primary py-20 text-center text-white"
      data-aos="zoom-in-down"
    >
      <h3 className="text-2xl font-bold font-lora">TESTIMONIALS</h3>
      <h2 className="text-3xl md:text-5xl lg:text-6xl font-montserrat text-black font-bold mt-2">
        Hear From Our Clients
      </h2>

      <div className="flex items-center justify-evenly mt-6 gap-6 font-lora text-xl">
        <button
          onClick={prevTestimonial}
          className="bg-white p-3 rounded-full text-green-500 shadow-lg"
        >
          <FaArrowLeft />
        </button>

        <motion.div
          key={index}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="w-2/3 max-w-xl"
        >
          <p className="mt-4 text-2xl sm:text-xl font-light">
            {testimonials[index].text}
          </p>
          <h4 className="mt-4 font-semibold">{testimonials[index].name}</h4>
          <div className="flex justify-center mt-2">
            {[...Array(5)].map((_, i) => (
              <FaStar key={i} className="text-red-400" />
            ))}
          </div>
        </motion.div>

        <button
          onClick={nextTestimonial}
          className="bg-white p-3 rounded-full text-green-500 shadow-lg"
        >
          <FaArrowRight />
        </button>
      </div>

      {/* Navigation Dots */}
      <div className="mt-4 flex justify-center gap-2">
        {testimonials.map((_, i) => (
          <button
            key={i}
            onClick={() => setIndex(i)}
            className={`w-3 h-3 rounded-full ${
              i === index ? "bg-red-500" : "bg-gray-300"
            }`}
          />
        ))}
      </div>

      {/* More Reviews Button */}
      <div className="mt-6">
        <a
          href="https://www.google.com/search?sca_esv=f4db438c9f87a94d&sxsrf=AHTn8zoQm-B-fPqYiTXV3Z_N7f3xDIKzXQ:1745508314416&si=APYL9bs7Hg2KMLB-4tSoTdxuOx8BdRvHbByC_AuVpNyh0x2Kzakj-GbCdSCkmqupr1KjpohNisQQTKommH0Zco98T6yEya8zN6FR9OvjIH7y93CINOoDB6gdLMXwW3xvQw7lV6g1Zb35Mm4NuSJOHYwRrIV1b36zUrFPOTdpiguNCM1hAB3DSIQ%3D&q=i-Revive+Cupping+Clinic+%28Hijama%29+Reviews&sa=X&ved=2ahUKEwir4qGY_fCMAxWGyTgGHRVlMx4Q0bkNegQIQBAE&biw=1920&bih=945&dpr=1"
          className="inline-block bg-white text-green-600 hover:bg-green-600 hover:text-white px-6 py-3 rounded-full font-montserrat transition duration-300"
        >
          More Reviews
        </a>
      </div>
    </section>
  );
}
